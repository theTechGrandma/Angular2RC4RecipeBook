import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'recipe-book-app',
  templateUrl: 'recipe-book.component.html',
  styleUrls: ['recipe-book.component.css']
})
export class RecipeBookAppComponent {
  title = 'recipe-book works!';
}
